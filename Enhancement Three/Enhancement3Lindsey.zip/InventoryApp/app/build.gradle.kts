plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
    id("com.google.gms.google-services") // Firebase plugin
    id("jacoco")
}

android {
    namespace = "com.example.inventoryapp"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.inventoryapp"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.3"
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true // ✅ Required for Robolectric
        unitTests.all {
            it.useJUnit() // ✅ Enables JUnit 4 engine
            it.extensions.configure<JacocoTaskExtension> {
                isIncludeNoLocationClasses = true
                excludes = listOf("jdk.internal.*")
            }
        }
    }
}

dependencies {
    // Core AndroidX
    implementation(libs.androidx.core.ktx.v1170)
    implementation(libs.androidx.appcompat.v161)
    implementation(libs.material.v1100)
    implementation(libs.androidx.constraintlayout)

    // RecyclerView
    implementation(libs.androidx.recyclerview)

    // Firebase
    implementation("com.google.firebase:firebase-auth:22.3.0")
    implementation(libs.firebase.firestore)
    implementation(libs.kotlinx.coroutines.play.services)

    // Kotlin Coroutines
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)

    // Jetpack Compose
    implementation(platform(libs.androidx.compose.bom.v20231001))
    implementation(libs.ui)
    implementation(libs.material3)
    implementation(libs.ui.tooling.preview)
    debugImplementation(libs.ui.tooling)

    // Unit Testing
    testImplementation(libs.junit) // ✅ JUnit 4
    testImplementation(libs.robolectric)     // ✅ Robolectric
    testImplementation(libs.mockk.v1138)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(kotlin("test"))

    // Instrumentation Testing
    androidTestImplementation(libs.junit.v115)
    androidTestImplementation(libs.androidx.runner)
    androidTestImplementation(libs.androidx.espresso.core.v351)
    androidTestImplementation(libs.androidx.espresso.intents)
}

tasks.withType<Test> {
    useJUnit() // ✅ JUnit 4 engine for all test tasks
    testLogging {
        events("passed", "skipped", "failed")
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
        showStandardStreams = true
    }
}

tasks.register<JacocoReport>("jacocoTestReport") {
    dependsOn("testDebugUnitTest")

    val classFiles = fileTree(project.layout.buildDirectory.dir("tmp/kotlin-classes/debug")) {
        exclude(
            "**/R.class",
            "**/R$*.class",
            "**/BuildConfig.*",
            "**/Manifest*.*",
            "**/*Test*.*"
        )
        include("**/*.class")
    }

    classDirectories.setFrom(files(classFiles))
    sourceDirectories.setFrom(files("src/main/java", "src/main/kotlin"))
    executionData.setFrom(files(project.layout.buildDirectory.file("jacoco/testDebugUnitTest.exec")))

    reports {
        xml.required.set(true)
        html.required.set(true)
        html.outputLocation.set(project.layout.buildDirectory.dir("reports/jacoco/test/html"))
    }

    doLast {
        println("✅ Jacoco report generated for InventoryAdapterTest")
        println(project.layout.buildDirectory.dir("reports/jacoco/test/html").get().asFile.absolutePath)
    }
}








