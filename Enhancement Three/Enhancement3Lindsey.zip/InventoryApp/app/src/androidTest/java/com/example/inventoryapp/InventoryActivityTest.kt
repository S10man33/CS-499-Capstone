package com.example.inventoryapp

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.inventoryapp.InventoryAdapter.OnItemEditListener
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate


@RunWith(AndroidJUnit4::class)
class InventoryAdapterTest {

    private lateinit var adapter: InventoryAdapter
    private var clickedPosition: Int? = null

    private val testItems = listOf(
        InventoryItem("Widget A", "2025-10-01", 10, LocalDate.of(2025, 12, 31)),
        InventoryItem("Widget B", "2025-10-02", 5, LocalDate.of(2025, 12, 31)),
        InventoryItem("Widget C", "2025-10-03", 20, LocalDate.of(2025, 12, 31))
    )


    @Before
    fun setup() {
        adapter = InventoryAdapter()
        adapter.items.clear()
        adapter.items.addAll(testItems)

        adapter.setOnItemEditListener(object : OnItemEditListener {
            override fun onEdit(position: Int) {
                clickedPosition = position
            }
        })
    }

    @Test
    fun bindViewHolder_displaysCorrectData() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val parent = LayoutInflater.from(context).inflate(R.layout.item_inventory, null)

        val viewHolder = adapter.onCreateViewHolder(parent as ViewGroup, 0)
        adapter.onBindViewHolder(viewHolder, 1)

        val nameText = viewHolder.itemView.findViewById<TextView>(R.id.itemName)
        val quantityText = viewHolder.itemView.findViewById<TextView>(R.id.itemQuantity)

        assertEquals("Widget B", nameText.text)
        assertEquals("Qty: 5", quantityText.text)
    }

    @Test
    fun itemClick_triggersEditListener() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val parent = LayoutInflater.from(context).inflate(R.layout.item_inventory, null)

        val viewHolder = adapter.onCreateViewHolder(parent as ViewGroup, 0)
        adapter.onBindViewHolder(viewHolder, 2)

        viewHolder.itemView.performClick()
        assertEquals(2, clickedPosition)
    }
}



