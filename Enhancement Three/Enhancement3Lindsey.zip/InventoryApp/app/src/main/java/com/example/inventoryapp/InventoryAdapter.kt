package com.example.inventoryapp

import android.annotation.SuppressLint
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDate

class InventoryAdapter : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

    val items = mutableListOf<InventoryItem>()

    interface OnItemEditListener {
        fun onEdit(position: Int)
    }

    interface OnItemDeleteListener {
        fun onDelete(position: Int)
    }

    private var editListener: OnItemEditListener? = null
    private var deleteListener: OnItemDeleteListener? = null

    fun setOnItemEditListener(listener: OnItemEditListener?) {
        editListener = listener
    }

    fun setOnItemDeleteListener(listener: OnItemDeleteListener?) {
        deleteListener = listener
    }

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(newList: List<InventoryItem>) {
        items.clear()
        items.addAll(newList)
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        val itemDate: TextView = itemView.findViewById(R.id.itemDate)
        val itemQuantity: TextView = itemView.findViewById(R.id.itemQuantity)
        val itemExpiration: TextView = itemView.findViewById(R.id.itemExpiration)
        val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_inventory, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.itemName.text = item.name
        holder.itemDate.text = item.date
        holder.itemQuantity.text = item.quantity.toString()
        holder.itemExpiration.text = item.expirationDate

        // Safely parse expirationDate and set color
        val parsedDate = runCatching { LocalDate.parse(item.expirationDate) }.getOrNull()
        holder.itemExpiration.setTextColor(
            if (parsedDate != null && parsedDate.isBefore(LocalDate.now())) Color.RED else Color.BLACK
        )

        holder.itemName.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                editListener?.onEdit(pos)
            }
        }

        holder.deleteButton.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                deleteListener?.onDelete(pos)
            }
        }
    }


    override fun getItemCount(): Int = items.size
}
















