package com.example.inventoryapp

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.utils.InputValidator
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar

class InventoryActivity : AppCompatActivity() {

    private val firebaseRepo = FirebaseRepository()
    private val inventoryList = mutableListOf<InventoryItem>()
    private lateinit var adapter: InventoryAdapter
    private val inventoryBST = InventoryBST()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        val inventoryGrid = findViewById<RecyclerView>(R.id.inventoryGrid)
        val addItemButton = findViewById<Button>(R.id.addItemButton)
        val searchButton = findViewById<Button>(R.id.searchButton)
        val homeButton = findViewById<Button>(R.id.homeButton)

        adapter = InventoryAdapter()
        adapter.submitList(inventoryList)

        inventoryGrid.layoutManager = LinearLayoutManager(this)
        inventoryGrid.adapter = adapter

        setupSortSpinner(findViewById(R.id.sortSpinner))

        loadInventory()

        addItemButton.setOnClickListener { showAddItemDialog() }

        searchButton.setOnClickListener { showSearchDialog() }

        adapter.setOnItemEditListener(object : InventoryAdapter.OnItemEditListener {
            override fun onEdit(position: Int) {
                showEditItemDialog(position)
            }
        })

        adapter.setOnItemDeleteListener(object : InventoryAdapter.OnItemDeleteListener {
            override fun onDelete(position: Int) {
                val item = inventoryList[position]
                if (item.id.isNullOrBlank()) {
                    Toast.makeText(this@InventoryActivity, "Missing item ID", Toast.LENGTH_SHORT).show()
                    return
                }

                AlertDialog.Builder(this@InventoryActivity)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure you want to delete '${item.name}'?")
                    .setPositiveButton("Delete") { _, _ ->
                        lifecycleScope.launch {
                            val result = firebaseRepo.deleteItem(item.id)
                            if (result is OperationResult.Success) {
                                inventoryList.removeAt(position)
                                adapter.submitList(inventoryList.toList())
                                Toast.makeText(this@InventoryActivity, "Item deleted", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        })

        homeButton.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            })
            finish()
        }
        val sortSpinner = findViewById<Spinner>(R.id.sortSpinner)
        val sortOptions = resources.getStringArray(R.array.sort_options)

        sortSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            sortOptions
        )

        sortSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedMode = SortMode.entries[position]
                val sortedList = when (selectedMode) {
                    SortMode.NAME -> inventoryList.sortedBy { it.name }
                    SortMode.DATE -> inventoryList.sortedBy { it.date }
                    SortMode.QUANTITY -> inventoryList.sortedBy { it.quantity }
                    SortMode.EXPIRATION -> inventoryList.sortedBy { it.expirationDate }
                }

                adapter.submitList(sortedList)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadInventory() {
        lifecycleScope.launch {
            val items = firebaseRepo.getAllItems()
            inventoryList.clear()
            inventoryList.addAll(items)
            adapter.submitList(inventoryList.toList())

            // Load items into BST
            inventoryBST.root = null
            items.forEach { inventoryBST.insert(it) }
        }
    }

    private fun setupSortSpinner(spinner: Spinner) {
        val sortOptions = SortMode.entries.map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sortOptions)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedMode = SortMode.entries[position]
                val sortedList = when (selectedMode) {
                    SortMode.NAME -> inventoryList.sortedBy { it.name }
                    SortMode.DATE -> inventoryList.sortedBy { it.date }
                    SortMode.QUANTITY -> inventoryList.sortedBy { it.quantity }
                    SortMode.EXPIRATION -> inventoryList.sortedBy { it.expirationDate }
                }
                inventoryList.clear()
                inventoryList.addAll(sortedList)
                adapter.submitList(inventoryList.toList())

            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }


    private fun showSearchDialog() {
        val dialogView = layoutInflater.inflate(R.layout.search_item, null)
        val categorySpinner = dialogView.findViewById<Spinner>(R.id.searchCategorySpinner)
        val valueInput = dialogView.findViewById<EditText>(R.id.searchValueInput)

        val categories = listOf("Product Type", "Date", "Quantity", "Expiration Date")
        categorySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )

        AlertDialog.Builder(this)
            .setTitle("Search Inventory")
            .setView(dialogView)
            .setPositiveButton("Search") { _, _ ->
                val selectedCategory = categorySpinner.selectedItem.toString()
                val query = valueInput.text.toString().trim()

                if (query.isEmpty()) {
                    Toast.makeText(this, "Please enter a search value", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val results = when (selectedCategory) {
                    "Product Type" -> inventoryList.filter { it.name.equals(query, ignoreCase = true) }
                    "Date" -> inventoryList.filter { it.date == query }
                    "Quantity" -> inventoryList.filter { it.quantity.toString() == query }
                    "Expiration Date" -> {
                        try {
                            val date = LocalDate.parse(query)
                            inventoryBST.search(date)?.let { listOf(it) } ?: emptyList()
                        } catch (e: Exception) {
                            Toast.makeText(this, "Invalid date format. Use YYYY-MM-DD", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                    }
                    else -> emptyList()
                }

                if (results.isNotEmpty()) {
                    Toast.makeText(this, "Found ${results.size} item(s)", Toast.LENGTH_SHORT).show()
                    // Optional: highlight or display results
                } else {
                    Toast.makeText(this, "No matching items found", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddItemDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.itemNameInput)
        val quantityInput = dialogView.findViewById<EditText>(R.id.itemQuantityInput)
        val dateInput = dialogView.findViewById<EditText>(R.id.itemDateInput)
        val expirationInput = dialogView.findViewById<EditText>(R.id.itemExpirationInput)

        val calendar = Calendar.getInstance()
        @SuppressLint("DefaultLocale")
        val today = String.format(
            "%04d-%02d-%02d",
            calendar[Calendar.YEAR],
            calendar[Calendar.MONTH] + 1,
            calendar[Calendar.DAY_OF_MONTH]
        )

        dateInput.setText(today)
        expirationInput.setText(today)

        dateInput.setOnClickListener { showDatePickerDialog(dateInput) }
        expirationInput.setOnClickListener { showDatePickerDialog(expirationInput) }

        AlertDialog.Builder(this)
            .setTitle("Add New Item")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim()
                val quantityStr = quantityInput.text.toString().trim()
                val date = dateInput.text.toString().trim()
                val expirationStr = expirationInput.text.toString().trim()

                if (!InputValidator.isNotEmpty(name, date, quantityStr, expirationStr)) {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (!InputValidator.isValidQuantity(quantityStr)) {
                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                try {
                    val item = InventoryItem(
                        name = name,
                        date = date,
                        quantity = quantityStr.toInt(),
                        expirationDate = expirationStr
                    )

                    lifecycleScope.launch {
                        val result = firebaseRepo.insertItem(item)
                        if (result is OperationResult.Success) {
                            val itemWithId = result.data
                            inventoryList.add(itemWithId)
                            adapter.submitList(inventoryList.toList())
                            inventoryBST.insert(itemWithId)
                            Toast.makeText(this@InventoryActivity, "Item added", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid expiration date format. Use YYYY-MM-DD", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }



    private fun showEditItemDialog(position: Int) {
        val item = inventoryList[position]
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.itemNameInput)
        val quantityInput = dialogView.findViewById<EditText>(R.id.itemQuantityInput)
        val dateInput = dialogView.findViewById<EditText>(R.id.itemDateInput)

        nameInput.setText(item.name)
        quantityInput.setText(item.quantity.toString())
        dateInput.setText(item.date)

        dateInput.setOnClickListener { showDatePickerDialog(dateInput) }

        AlertDialog.Builder(this)
            .setTitle("Edit Item")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newName = nameInput.text.toString().trim()
                val quantityStr = quantityInput.text.toString().trim()
                val newDate = dateInput.text.toString().trim()

                if (!InputValidator.isNotEmpty(newName, newDate, quantityStr)) {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (!InputValidator.isValidQuantity(quantityStr)) {
                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                try {
                    val updatedItem = InventoryItem(
                        name = newName,
                        date = newDate,
                        quantity = quantityStr.toInt(),
                        expirationDate = newDate,
                        priority = item.priority,
                        id = item.id
                    )

                    lifecycleScope.launch {
                        val result = firebaseRepo.updateItem(item.id ?: "", updatedItem)
                        if (result is OperationResult.Success) {
                            inventoryList[position] = updatedItem
                            adapter.notifyItemChanged(position)
                            loadInventory()
                            Toast.makeText(this@InventoryActivity, "Item updated", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid date format. Use YYYY-MM-DD", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun showDatePickerDialog(targetField: EditText) {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                @SuppressLint("DefaultLocale")
                val formattedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                targetField.setText(formattedDate)
            },
            calendar[Calendar.YEAR],
            calendar[Calendar.MONTH],
            calendar[Calendar.DAY_OF_MONTH]
        )
        datePicker.show()
    }
}





















