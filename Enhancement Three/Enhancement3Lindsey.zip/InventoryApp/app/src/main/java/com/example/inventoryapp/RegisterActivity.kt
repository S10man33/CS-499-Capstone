package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var etNewEmail: EditText
    private lateinit var etNewPass: EditText
    private lateinit var btnRegister: Button
    private lateinit var backToLoginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()

        etNewEmail = findViewById(R.id.etNewEmail)
        etNewPass = findViewById(R.id.etNewPass)
        btnRegister = findViewById(R.id.btnRegister)
        backToLoginButton = findViewById(R.id.backToLoginButton)

        btnRegister.setOnClickListener {
            val email = etNewEmail.text.toString().trim()
            val password = etNewPass.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email and password are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener {
                    Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show()
                    Log.d("Register", "Account created for $email")
                    finish() // Return to login screen
                }
                .addOnFailureListener { e ->
                    Log.e("Register", "Registration failed", e)
                    Toast.makeText(this, "Registration failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        backToLoginButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }
}








