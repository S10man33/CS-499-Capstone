package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.inventoryapp.utils.InputValidator
import kotlinx.coroutines.launch

class ChangePasswordActivity : AppCompatActivity() {

    private lateinit var firebaseRepo: FirebaseRepository

    private lateinit var etOldPassword: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnChangePassword: Button
    private lateinit var homeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        etOldPassword = findViewById(R.id.etOldPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnChangePassword = findViewById(R.id.btnChangePassword)
        homeButton = findViewById(R.id.homeButton)

        btnChangePassword.setOnClickListener {
            changePassword()
        }

        homeButton.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }

    private fun changePassword() {
        val oldPassword = etOldPassword.text.toString().trim()
        val newPassword = etNewPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()
        val email = firebaseRepo.getCurrentUserEmail()

        if (!InputValidator.isNotEmpty(oldPassword, newPassword, confirmPassword)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (!InputValidator.isStrongPassword(newPassword)) {
            Toast.makeText(
                this,
                "Password must be at least 8 characters, include a number and uppercase letter",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (!InputValidator.doPasswordsMatch(newPassword, confirmPassword)) {
            Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val loginResult = firebaseRepo.loginUser(email, oldPassword)

                if (loginResult is OperationResult.Success) {
                    val updateResult = firebaseRepo.updateUserPassword(oldPassword, newPassword)

                    if (updateResult is OperationResult.Success) {
                        Toast.makeText(
                            this@ChangePasswordActivity,
                            "Password updated successfully!",
                            Toast.LENGTH_SHORT
                        ).show()

                        Handler(Looper.getMainLooper()).postDelayed({
                            startActivity(Intent(this@ChangePasswordActivity, HomeActivity::class.java))
                            finish()
                        }, 1500)
                    } else {
                        val message = (updateResult as OperationResult.Failure).message
                        Toast.makeText(
                            this@ChangePasswordActivity,
                            "Update failed: $message",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    val message = (loginResult as OperationResult.Failure).message
                    Toast.makeText(
                        this@ChangePasswordActivity,
                        "Incorrect old password: $message",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@ChangePasswordActivity,
                    "Unexpected error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // For testing: allow injection of mock repository
    fun injectRepository(repo: FirebaseRepository) {
        this.firebaseRepo = repo
    }
}













