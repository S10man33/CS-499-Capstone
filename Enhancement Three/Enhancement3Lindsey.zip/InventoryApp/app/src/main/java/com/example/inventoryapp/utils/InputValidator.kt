package com.example.inventoryapp.utils

object InputValidator {

    fun isNotEmpty(vararg inputs: String): Boolean {
        if (inputs.isEmpty()) return false
        return inputs.all { it.trim().isNotEmpty() }
    }

    fun isValidEmail(email: String): Boolean {
        val trimmed = email.trim()
        val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")
        return trimmed.isNotEmpty() && emailRegex.matches(trimmed)
    }

    fun isStrongPassword(password: String): Boolean {
        val trimmed = password.trim()
        println("DEBUG: password='$password', trimmed='$trimmed'")

        if (trimmed.isEmpty()) {
            println("DEBUG: Empty password detected → returning false")
            return false
        }

        if (trimmed.length < 8) {
            println("DEBUG: Too short → returning false")
            return false
        }

        val hasUpper = trimmed.contains(Regex("[A-Z]"))
        val hasLower = trimmed.contains(Regex("[a-z]"))
        val hasDigit = trimmed.contains(Regex("[0-9]"))
        val hasSymbol = trimmed.contains(Regex("[^A-Za-z0-9]"))

        println("DEBUG: Upper=$hasUpper, Lower=$hasLower, Digit=$hasDigit, Symbol=$hasSymbol")
        println("DEBUG: password='$password', trimmed='${password.trim()}'")

        return hasUpper && hasLower && hasDigit && hasSymbol
    }

    fun doPasswordsMatch(password1: String, password2: String): Boolean {
        return password1 == password2
    }

    fun isValidQuantity(quantity: String): Boolean {
        val trimmed = quantity.trim()
        return trimmed.toIntOrNull()?.let { it >= 0 } ?: false
    }

    fun isValidPrice(price: String): Boolean {
        val trimmed = price.trim()
        return trimmed.toDoubleOrNull()?.let { it >= 0.0 } ?: false
    }
}























