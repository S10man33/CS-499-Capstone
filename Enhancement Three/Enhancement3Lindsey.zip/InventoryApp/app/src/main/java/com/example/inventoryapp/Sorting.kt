package com.example.inventoryapp

enum class SortMode {
    NAME,
    DATE,
    QUANTITY,
    EXPIRATION
}
