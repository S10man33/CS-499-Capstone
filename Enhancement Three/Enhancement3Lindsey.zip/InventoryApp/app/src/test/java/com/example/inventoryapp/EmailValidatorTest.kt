package com.example.inventoryapp

import com.example.inventoryapp.utils.InputValidator
import org.junit.Test
import org.junit.Assert.*


class EmailValidatorTest {

    @Test fun `valid email passes`() {
        assertTrue(InputValidator.isValidEmail("test@example.com"))
    }

    @Test fun `missing @ fails`() {
        assertFalse(InputValidator.isValidEmail("testexample.com"))
    }

    @Test fun `missing domain fails`() {
        assertFalse(InputValidator.isValidEmail("test@"))
    }

    @Test fun `missing username fails`() {
        assertFalse(InputValidator.isValidEmail("@example.com"))
    }

    @Test fun `empty string fails`() {
        assertFalse(InputValidator.isValidEmail(""))
    }

    @Test fun `whitespace is trimmed`() {
        assertTrue(InputValidator.isValidEmail("  test@example.com  "))
    }
}







