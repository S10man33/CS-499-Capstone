package com.example.inventoryapp

import com.example.inventoryapp.utils.InputValidator
import com.google.android.gms.tasks.TaskCompletionSource
import com.google.firebase.auth.*
import com.google.firebase.firestore.*
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import kotlinx.coroutines.test.runTest
import org.junit.Test
import java.time.LocalDate
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Before


class FirebaseRepositoryTest {

    private lateinit var repo: FirebaseRepository
    private lateinit var mockAuth: FirebaseAuth
    private lateinit var mockFirestore: FirebaseFirestore
    private lateinit var mockUser: FirebaseUser
    private lateinit var mockCredential: AuthCredential
    private lateinit var mockDocRef: DocumentReference
    private lateinit var mockCollection: CollectionReference

    private val validItem = InventoryItem(
        name = "Apples",
        date = "2025-09-25",
        quantity = 10,
        expirationDate = LocalDate.of(2025, 10, 1),
        id = "abc123"
    )

    @Before
    fun setup() {
        mockAuth = mockk()
        mockFirestore = mockk()
        mockUser = mockk()
        mockCredential = mockk()
        mockDocRef = mockk()
        mockCollection = mockk()

        mockkObject(InputValidator)
        every { InputValidator.isValidEmail(any()) } returns true
        every { InputValidator.isStrongPassword(any()) } returns true
        every { InputValidator.isNotEmpty(any(), any()) } returns true
        every { InputValidator.isValidQuantity(any()) } returns true

        repo = FirebaseRepository(db = mockFirestore, auth = mockAuth)
    }

    @Test
    fun `registerUser returns success`() = runTest {
        val authTask = TaskCompletionSource<AuthResult>().apply { setResult(mockk()) }
        val setTask = TaskCompletionSource<Void>().apply { setResult(null) }

        every { mockAuth.createUserWithEmailAndPassword(any(), any()) } returns authTask.task
        every { mockAuth.currentUser } returns mockUser
        every { mockUser.uid } returns "uid123"
        every { mockFirestore.collection("users") } returns mockCollection
        every { mockCollection.document("uid123") } returns mockDocRef
        every { mockDocRef.set(any()) } returns setTask.task

        val result = repo.registerUser("test@example.com", "StrongPass123")
        assertTrue(result is OperationResult.Success)
        assertEquals(Unit, (result as OperationResult.Success).data)
    }

    @Test
    fun `registerUser fails with invalid email`() = runTest {
        every { InputValidator.isValidEmail(any()) } returns false
        val result = repo.registerUser("bademail", "StrongPass123")
        assertTrue(result is OperationResult.Failure)
        assertEquals("Invalid email format", (result as OperationResult.Failure).message)
    }

    @Test
    fun `loginUser returns success`() = runTest {
        val loginTask = TaskCompletionSource<AuthResult>().apply { setResult(mockk()) }
        every { mockAuth.signInWithEmailAndPassword(any(), any()) } returns loginTask.task

        val result = repo.loginUser("test@example.com", "StrongPass123")
        assertTrue(result is OperationResult.Success)
        assertEquals(Unit, (result as OperationResult.Success).data)
    }

    @Test
    fun `updateUserPassword fails with weak password`() = runTest {
        every { InputValidator.isStrongPassword(any()) } returns false
        every { mockAuth.currentUser } returns mockUser
        every { mockUser.email } returns "test@example.com"

        val result = repo.updateUserPassword("oldPass", "weak")
        assertTrue(result is OperationResult.Failure)
        assertEquals("Weak password", (result as OperationResult.Failure).message)
    }

    @Test
    fun `insertItem returns success`() = runTest {
        val setTask = TaskCompletionSource<Void>().apply { setResult(null) }

        every { mockFirestore.collection("inventory") } returns mockCollection
        every { mockCollection.document() } returns mockDocRef
        every { mockDocRef.set(any()) } returns setTask.task
        every { mockDocRef.id } returns "abc123"

        val result = repo.insertItem(validItem)
        assertTrue(result is OperationResult.Success)
        assertEquals(Unit, (result as OperationResult.Success).data)
    }

    @Test
    fun `insertItem fails with invalid quantity`() = runTest {
        every { InputValidator.isValidQuantity(any()) } returns false
        val result = repo.insertItem(validItem)
        assertTrue(result is OperationResult.Failure)
        assertEquals("Invalid quantity", (result as OperationResult.Failure).message)
    }

    @Test
    fun `updateItem returns success`() = runTest {
        val setTask = TaskCompletionSource<Void>().apply { setResult(null) }

        every { mockFirestore.collection("inventory") } returns mockCollection
        every { mockCollection.document("abc123") } returns mockDocRef
        every { mockDocRef.set(validItem) } returns setTask.task

        val result = repo.updateItem("abc123", validItem)
        assertTrue(result is OperationResult.Success)
        assertEquals(Unit, (result as OperationResult.Success).data)
    }

    @Test
    fun `updateItem fails with blank ID`() = runTest {
        val result = repo.updateItem("", validItem)
        assertTrue(result is OperationResult.Failure)
        assertEquals("Missing item ID", (result as OperationResult.Failure).message)
    }

    @Test
    fun `deleteItem returns success`() = runTest {
        val deleteTask = TaskCompletionSource<Void>().apply { setResult(null) }

        every { mockFirestore.collection("inventory") } returns mockCollection
        every { mockCollection.document("abc123") } returns mockDocRef
        every { mockDocRef.delete() } returns deleteTask.task

        val result = repo.deleteItem("abc123")
        assertTrue(result is OperationResult.Success)
        assertEquals(Unit, (result as OperationResult.Success).data)
    }

    @Test
    fun `deleteItem fails with blank ID`() = runTest {
        val result = repo.deleteItem("")
        assertTrue(result is OperationResult.Failure)
        assertEquals("Missing item ID", (result as OperationResult.Failure).message)
    }

    @Test
    fun `getAllItems returns expected list`() = runTest {
        val queryTask = TaskCompletionSource<QuerySnapshot>()
        val mockSnapshot = mockk<QuerySnapshot>()
        val mockDoc = mockk<DocumentSnapshot>()

        every { mockFirestore.collection("inventory") } returns mockCollection
        every { mockCollection.orderBy("name") } returns mockCollection
        every { mockCollection.get() } returns queryTask.task

        every { mockSnapshot.documents } returns listOf(mockDoc)
        every { mockDoc.toObject(InventoryItem::class.java) } returns validItem
        every { mockDoc.id } returns "abc123"

        queryTask.setResult(mockSnapshot)

        val result = repo.getAllItems()
        assertEquals(1, result.size)
        assertEquals("abc123", result[0].id)
        assertEquals("Apples", result[0].name)
    }

    @Test
    fun `getAllItems returns empty list on exception`() = runTest {
        val queryTask = TaskCompletionSource<QuerySnapshot>()
        queryTask.setException(Exception("Firestore error"))

        every { mockFirestore.collection("inventory") } returns mockCollection
        every { mockCollection.orderBy("name") } returns mockCollection
        every { mockCollection.get() } returns queryTask.task

        val result = repo.getAllItems()
        assertTrue(result.isEmpty())
    }
}








