package com.example.inventoryapp

import android.os.Looper
import android.widget.Button
import android.widget.EditText
import com.example.inventoryapp.utils.InputValidator
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowToast
import java.time.Duration

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [30])
class ChangePasswordActivityTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setupDispatcher() {
        Dispatchers.setMain(testDispatcher)
        mockkObject(InputValidator)
    }

    @After
    fun tearDownDispatcher() {
        Dispatchers.resetMain()
    }

    private fun setupActivityWithMock(repo: FirebaseRepository): ChangePasswordActivity {
        val controller = Robolectric.buildActivity(ChangePasswordActivity::class.java)
        val activity = controller.get()
        activity.injectRepository(repo)
        controller.setup()
        return activity
    }

    @Test
    fun `empty fields show toast error`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns false

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()

        val toastText = ShadowToast.getTextOfLatestToast()?.toString()?.trim()
        assertEquals("Please fill all fields", toastText)
    }

    @Test
    fun `weak password shows toast error`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns true
        every { InputValidator.isStrongPassword("weak") } returns false

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("OldPass1")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("weak")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("weak")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()

        val toastText = ShadowToast.getTextOfLatestToast()?.toString()?.trim()
        assertEquals(
            "Password must be at least 8 characters, include a number and uppercase letter",
            toastText
        )
    }

    @Test
    fun `mismatched passwords show toast error`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns true
        every { InputValidator.isStrongPassword("StrongPass1") } returns true
        every { InputValidator.doPasswordsMatch("StrongPass1", "WrongPass1") } returns false

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("OldPass1")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("StrongPass1")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("WrongPass1")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()

        val toastText = ShadowToast.getTextOfLatestToast()?.toString()?.trim()
        assertEquals("New passwords do not match", toastText)
    }

    @Test
    fun `valid input triggers password update and navigates home`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns true
        every { InputValidator.isStrongPassword("StrongPass1") } returns true
        every { InputValidator.doPasswordsMatch("StrongPass1", "StrongPass1") } returns true
        coEvery { repo.loginUser(any(), any()) } returns OperationResult.Success(Unit)
        coEvery { repo.updateUserPassword(any(), any()) } returns OperationResult.Success(Unit)

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("OldPass1")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("StrongPass1")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("StrongPass1")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()
        Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1500))

        val intent = Shadows.shadowOf(activity).nextStartedActivity
        assertNotNull(intent)
        val componentName = intent.component
        assertEquals(HomeActivity::class.java.name, componentName?.className)
    }

    @Test
    fun `update failure shows toast`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns true
        every { InputValidator.isStrongPassword("StrongPass1") } returns true
        every { InputValidator.doPasswordsMatch("StrongPass1", "StrongPass1") } returns true
        coEvery { repo.loginUser(any(), any()) } returns OperationResult.Success(Unit)
        coEvery { repo.updateUserPassword(any(), any()) } returns OperationResult.Failure("Update failed")

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("OldPass1")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("StrongPass1")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("StrongPass1")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()

        val toastText = ShadowToast.getTextOfLatestToast()?.toString()?.trim()
        assertEquals("Update failed: Update failed", toastText)
    }

    @Test
    fun `login failure shows toast`() = runTest {
        val repo = mockk<FirebaseRepository>()
        every { repo.getCurrentUserEmail() } returns "user@example.com"
        every { InputValidator.isNotEmpty(any(), any(), any()) } returns true
        every { InputValidator.isStrongPassword("StrongPass1") } returns true
        every { InputValidator.doPasswordsMatch("StrongPass1", "StrongPass1") } returns true
        coEvery { repo.loginUser(any(), any()) } returns OperationResult.Failure("Login failed")

        val activity = setupActivityWithMock(repo)

        activity.findViewById<EditText>(R.id.etOldPassword).setText("OldPass1")
        activity.findViewById<EditText>(R.id.etNewPassword).setText("StrongPass1")
        activity.findViewById<EditText>(R.id.etConfirmPassword).setText("StrongPass1")

        activity.findViewById<Button>(R.id.btnChangePassword).performClick()
        testDispatcher.scheduler.advanceUntilIdle()

        val toastText = ShadowToast.getTextOfLatestToast()?.toString()?.trim()
        assertEquals("Incorrect old password: Login failed", toastText)
    }
}















