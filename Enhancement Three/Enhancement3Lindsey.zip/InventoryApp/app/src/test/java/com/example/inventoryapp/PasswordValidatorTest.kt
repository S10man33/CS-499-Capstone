package com.example.inventoryapp

import com.example.inventoryapp.utils.InputValidator
import org.junit.Test
import org.junit.Assert.*


class PasswordValidatorTest {

    @Test fun `strong password passes`() {
        assertTrue(InputValidator.isStrongPassword("StrongPass1!"))
    }

    @Test fun `short password fails`() {
        assertFalse(InputValidator.isStrongPassword("S1!a"))
    }

    @Test fun `missing digit fails`() {
        assertFalse(InputValidator.isStrongPassword("StrongPass!"))
    }

    @Test fun `missing uppercase fails`() {
        assertFalse(InputValidator.isStrongPassword("strongpass1!"))
    }

    @Test fun `missing lowercase fails`() {
        assertFalse(InputValidator.isStrongPassword("STRONG1!"))
    }

    @Test fun `missing symbol fails`() {
        assertFalse(InputValidator.isStrongPassword("StrongPass1"))
    }

    @Test fun `empty string fails`() {
        assertFalse(InputValidator.isStrongPassword(""))
    }

    @Test fun `only digits fails`() {
        assertFalse(InputValidator.isStrongPassword("12345678"))
    }

    @Test fun `only uppercase fails`() {
        assertFalse(InputValidator.isStrongPassword("PASSWORD1!"))
    }
}
