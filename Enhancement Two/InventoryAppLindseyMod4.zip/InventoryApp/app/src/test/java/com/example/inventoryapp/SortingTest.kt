package com.example.inventoryapp

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.time.LocalDate
import java.util.PriorityQueue

class SortingTest {

    private val itemA = InventoryItem("Apples", "2025-09-25", 10, LocalDate.of(2025, 10, 1))
    private val itemB = InventoryItem("Bananas", "2025-09-26", 5, LocalDate.of(2025, 9, 30))
    private val itemC = InventoryItem("Carrots", "2025-09-27", 20, LocalDate.of(2025, 10, 5))
    private val itemD = InventoryItem("Dates", "2025-09-28", 0, LocalDate.of(2025, 10, 1)) // same expiration as itemA
    private val itemE = InventoryItem("", "2025-09-29", 15, LocalDate.of(2025, 10, 10)) // blank name
    private val itemF = InventoryItem("Eggs", "2025-09-30", -3, LocalDate.of(2025, 10, 15)) // negative quantity

    private val inventory = listOf(itemA, itemB, itemC, itemD)

    @Test
    fun `sort by expiration date ascending`() {
        val sorted = inventory.sortedBy { it.expirationDate }
        assertEquals(listOf(itemB, itemA, itemD, itemC), sorted)
    }

    @Test
    fun `sort by quantity descending`() {
        val sorted = inventory.sortedByDescending { it.quantity }
        assertEquals(listOf(itemC, itemA, itemB, itemD), sorted)
    }

    @Test
    fun `filter expired items`() {
        val today = LocalDate.of(2025, 10, 2)
        val expired = inventory
            .filter { it.expirationDate.isBefore(today) }
            .sortedBy { it.expirationDate }

        assertEquals(listOf(itemB, itemA, itemD), expired)

    }

    @Test
    fun `priority queue orders by expiration`() {
        val queue = PriorityQueue<InventoryItem>(compareBy { it.expirationDate })
        queue.addAll(inventory)

        assertEquals(itemB, queue.poll()) // earliest
        val second = queue.poll()
        val third = queue.poll()
        assertTrue(setOf(itemA, itemD).containsAll(listOf(second, third) as Collection<InventoryItem>))
        assertEquals(itemC, queue.poll()) // latest
    }


    @Test
    fun `reject blank item name`() {
        assertTrue(itemE.name.isBlank(), "Item name should not be blank")
    }

    @Test
    fun `reject negative quantity`() {
        assertTrue(itemF.quantity < 0, "Quantity should not be negative")
    }

    @Test
    fun `sort empty inventory list`() {
        val emptyList = emptyList<InventoryItem>()
        val sorted = emptyList.sortedBy { it.expirationDate }
        assertTrue(sorted.isEmpty())
    }

    @Test
    fun `filter with no expired items`() {
        val futureDate = LocalDate.of(2025, 9, 1)
        val expired = inventory.filter { it.expirationDate.isBefore(futureDate) }
        assertTrue(expired.isEmpty())
    }
}


