package com.example.inventoryapp

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.time.LocalDate

class InventoryBSTTest {

    private val itemA = InventoryItem("Apples", "2025-09-25", 10, LocalDate.of(2025, 10, 1))
    private val itemB = InventoryItem("Bananas", "2025-09-26", 5, LocalDate.of(2025, 9, 30))
    private val itemC = InventoryItem("Carrots", "2025-09-27", 20, LocalDate.of(2025, 10, 5))
    private val itemD = InventoryItem("Dates", "2025-09-28", 0, LocalDate.of(2025, 10, 1)) // same expiration as itemA

    @Test
    fun `insert and search returns correct item`() {
        val bst = InventoryBST()
        bst.insert(itemA)
        bst.insert(itemB)
        bst.insert(itemC)

        assertEquals(itemB, bst.search(LocalDate.of(2025, 9, 30)))
        assertEquals(itemA, bst.search(LocalDate.of(2025, 10, 1)))
        assertEquals(itemC, bst.search(LocalDate.of(2025, 10, 5)))
    }

    @Test
    fun `search returns null for missing expiration date`() {
        val bst = InventoryBST()
        bst.insert(itemA)
        assertNull(bst.search(LocalDate.of(2025, 9, 1)))
    }

    @Test
    fun `insert handles duplicate expiration dates`() {
        val bst = InventoryBST()
        bst.insert(itemA)
        bst.insert(itemD) // same expiration date

        val result = bst.search(LocalDate.of(2025, 10, 1))
        assertNotNull(result)
        assertTrue(result == itemA || result == itemD)
    }

    @Test
    fun `search in empty tree returns null`() {
        val bst = InventoryBST()
        assertNull(bst.search(LocalDate.of(2025, 10, 1)))
    }

    @Test
    fun `insert multiple items builds correct structure`() {
        val bst = InventoryBST()
        bst.insert(itemB) // root
        bst.insert(itemA) // right of root
        bst.insert(itemC) // right of itemA

        assertEquals(itemB, bst.root?.item)
        assertEquals(itemA, bst.root?.right?.item)
        assertEquals(itemC, bst.root?.right?.right?.item)
    }
}

