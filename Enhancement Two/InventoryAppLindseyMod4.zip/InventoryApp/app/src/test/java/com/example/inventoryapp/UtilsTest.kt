package com.example.inventoryapp

import com.example.inventoryapp.utils.InputValidator
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class UtilsTest {

    @Test
    fun `isNotEmpty returns true for non-empty fields`() {
        assertTrue(InputValidator.isNotEmpty("Apples", "2025-09-25"))
    }

    @Test
    fun `isNotEmpty returns false for blank fields`() {
        assertFalse(InputValidator.isNotEmpty("Apples", ""))
    }

    @Test
    fun `isValidEmail returns true for valid email`() {
        assertTrue(InputValidator.isValidEmail("test@example.com"))
    }

    @Test
    fun `isValidEmail returns false for invalid email`() {
        assertFalse(InputValidator.isValidEmail("invalid-email"))
    }

    @Test
    fun `isStrongPassword returns true for strong password`() {
        assertTrue(InputValidator.isStrongPassword("StrongPass1"))
    }

    @Test
    fun `isStrongPassword returns false for short password`() {
        assertFalse(InputValidator.isStrongPassword("S1"))
    }

    @Test
    fun `isStrongPassword returns false for missing digit`() {
        assertFalse(InputValidator.isStrongPassword("StrongPass"))
    }

    @Test
    fun `isStrongPassword returns false for missing uppercase`() {
        assertFalse(InputValidator.isStrongPassword("strongpass1"))
    }

    @Test
    fun `doPasswordsMatch returns true for matching passwords`() {
        assertTrue(InputValidator.doPasswordsMatch("abc123", "abc123"))
    }

    @Test
    fun `doPasswordsMatch returns false for mismatched passwords`() {
        assertFalse(InputValidator.doPasswordsMatch("abc123", "xyz789"))
    }

    @Test
    fun `isValidQuantity returns true for valid quantity`() {
        assertTrue(InputValidator.isValidQuantity("10"))
    }

    @Test
    fun `isValidQuantity returns false for negative quantity`() {
        assertFalse(InputValidator.isValidQuantity("-5"))
    }

    @Test
    fun `isValidQuantity returns false for non-numeric input`() {
        assertFalse(InputValidator.isValidQuantity("ten"))
    }

    @Test
    fun `isValidPrice returns true for valid price`() {
        assertTrue(InputValidator.isValidPrice("19.99"))
    }

    @Test
    fun `isValidPrice returns false for negative price`() {
        assertFalse(InputValidator.isValidPrice("-3.50"))
    }

    @Test
    fun `isValidPrice returns false for non-numeric input`() {
        assertFalse(InputValidator.isValidPrice("free"))
    }
}

