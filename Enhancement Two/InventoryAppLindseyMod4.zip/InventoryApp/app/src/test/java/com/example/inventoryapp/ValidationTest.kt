package com.example.inventoryapp

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.time.LocalDate

class ValidationTest {

    @Test
    fun `blank name is invalid`() {
        val item = InventoryItem("", "2025-09-29", 15, LocalDate.of(2025, 10, 10))
        assertTrue(item.name.isBlank())
    }

    @Test
    fun `negative quantity is invalid`() {
        val item = InventoryItem("Eggs", "2025-09-30", -3, LocalDate.of(2025, 10, 15))
        assertTrue(item.quantity < 0)
    }

    @Test
    fun `valid item passes validation`() {
        val item = InventoryItem("Milk", "2025-09-30", 2, LocalDate.of(2025, 10, 10))
        assertFalse(item.name.isBlank())
        assertTrue(item.quantity >= 0)
    }
}
