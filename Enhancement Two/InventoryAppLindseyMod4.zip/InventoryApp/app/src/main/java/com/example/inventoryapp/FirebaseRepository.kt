package com.example.inventoryapp

import com.example.inventoryapp.utils.InputValidator
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.time.LocalDate

sealed class OperationResult {
    object Success : OperationResult()
    data class Failure(val message: String, val exception: Exception? = null) : OperationResult()
}

object Logger {
    fun error(tag: String, message: String, throwable: Throwable? = null) {
        println("[$tag] $message ${throwable?.message}")
    }
}

class FirebaseRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun createCredential(email: String, password: String): AuthCredential {
        return EmailAuthProvider.getCredential(email, password)
    }

    suspend fun registerUser(email: String, password: String): OperationResult {
        if (!InputValidator.isValidEmail(email)) {
            return OperationResult.Failure("Invalid email format")
        }
        if (!InputValidator.isStrongPassword(password)) {
            return OperationResult.Failure("Weak password")
        }

        return try {
            auth.createUserWithEmailAndPassword(email, password).await()
            val uid = auth.currentUser?.uid ?: return OperationResult.Failure("User creation failed")
            db.collection("users").document(uid).set(mapOf("email" to email)).await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Registration failed", e)
            OperationResult.Failure(e.message ?: "Registration failed", e)
        }
    }

    suspend fun loginUser(email: String, password: String): OperationResult {
        return try {
            auth.signInWithEmailAndPassword(email, password).await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Login failed", e)
            OperationResult.Failure(e.message ?: "Login failed", e)
        }
    }

    suspend fun updateUserPassword(oldPassword: String, newPassword: String): OperationResult {
        val user = auth.currentUser ?: return OperationResult.Failure("No authenticated user")
        val email = user.email ?: return OperationResult.Failure("Missing email")

        if (!InputValidator.isStrongPassword(newPassword)) {
            return OperationResult.Failure("Weak password")
        }

        return try {
            val credential = createCredential(email, oldPassword)
            user.reauthenticate(credential).await()
            user.updatePassword(newPassword).await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Password update failed", e)
            OperationResult.Failure(e.message ?: "Password update failed", e)
        }
    }

    suspend fun insertItem(item: InventoryItem): OperationResult {
        if (!InputValidator.isNotEmpty(item.name, item.date)) {
            return OperationResult.Failure("Name and date required")
        }
        if (!InputValidator.isValidQuantity(item.quantity.toString())) {
            return OperationResult.Failure("Invalid quantity")
        }

        return try {
            val docRef = db.collection("inventory").document()
            val itemWithId = item.copy(id = docRef.id)
            docRef.set(itemWithId).await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Insert failed", e)
            OperationResult.Failure(e.message ?: "Insert failed", e)
        }
    }

    suspend fun updateItem(itemId: String, item: InventoryItem): OperationResult {
        if (itemId.isBlank()) {
            return OperationResult.Failure("Missing item ID")
        }
        if (!InputValidator.isNotEmpty(item.name, item.date)) {
            return OperationResult.Failure("Name and date required")
        }
        if (!InputValidator.isValidQuantity(item.quantity.toString())) {
            return OperationResult.Failure("Invalid quantity")
        }

        return try {
            db.collection("inventory").document(itemId).set(item).await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Update failed", e)
            OperationResult.Failure(e.message ?: "Update failed", e)
        }
    }

    suspend fun deleteItem(itemId: String): OperationResult {
        if (itemId.isBlank()) {
            return OperationResult.Failure("Missing item ID")
        }

        return try {
            db.collection("inventory").document(itemId).delete().await()
            OperationResult.Success
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Delete failed", e)
            OperationResult.Failure(e.message ?: "Delete failed", e)
        }
    }

    suspend fun getAllItems(): List<InventoryItem> {
        return try {
            val snapshot = db.collection("inventory").orderBy("name").get().await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(InventoryItem::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            Logger.error("FirebaseRepository", "Fetch failed", e)
            emptyList()
        }
    }
}
















