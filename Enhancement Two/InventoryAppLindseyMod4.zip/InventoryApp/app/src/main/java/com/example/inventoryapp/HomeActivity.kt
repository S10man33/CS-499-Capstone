package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

// Main navigation hub of the app — directs users to key features
class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Set up navigation icons with click listeners
        findViewById<ImageView>(R.id.inventoryIcon)?.setOnClickListener {
            startActivity(Intent(this, InventoryActivity::class.java))
        }

        findViewById<ImageView>(R.id.smsIcon)?.setOnClickListener {
            startActivity(Intent(this, NotificationActivity::class.java))
        }

        findViewById<ImageView>(R.id.settingsIcon)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}



