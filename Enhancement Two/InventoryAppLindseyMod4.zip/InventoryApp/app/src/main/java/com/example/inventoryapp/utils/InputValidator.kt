package com.example.inventoryapp.utils

object InputValidator {

    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")

    fun isNotEmpty(vararg fields: String): Boolean {
        return fields.all { it.isNotBlank() }
    }

    fun isValidEmail(email: String): Boolean {
        return EMAIL_REGEX.matches(email)
    }

    fun isStrongPassword(password: String): Boolean {
        return password.length >= 8 &&
                password.any { it.isDigit() } &&
                password.any { it.isUpperCase() }
    }

    fun doPasswordsMatch(pw1: String, pw2: String): Boolean {
        return pw1 == pw2
    }

    fun isValidQuantity(quantity: String): Boolean {
        return quantity.toIntOrNull()?.let { it >= 0 } == true
    }

    fun isValidPrice(price: String): Boolean {
        return price.toDoubleOrNull()?.let { it >= 0.0 } == true
    }

    fun <T : CharSequence?> checkStringNotEmpty(string: T, errorMessage: String = "String must not be empty"): T {
        require(!string.isNullOrEmpty()) { errorMessage }
        return string
    }
}


