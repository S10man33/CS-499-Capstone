package com.example.inventoryapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Handles SMS notification functionality, including permission requests,
 * sending test messages, and navigating back to the home screen.
 */
class NotificationActivity : AppCompatActivity() {

    private lateinit var requestSMSButton: Button
    private lateinit var sendSmsButton: Button
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        requestSMSButton = findViewById(R.id.requestSMSButton)
        sendSmsButton = findViewById(R.id.sendSmsButton)
        statusText = findViewById(R.id.statusText)
        val homeButton = findViewById<Button>(R.id.homeButton)

        checkSmsPermission()

        requestSMSButton.setOnClickListener {
            requestSmsPermission()
        }

        sendSmsButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                sendSMS()
            } else {
                Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show()
            }
        }

        homeButton.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            })
            finish()
        }
    }

    private fun sendSMS() {
        val phoneNumber = "1234567890" // Replace with dynamic input if needed
        val message = "Test alert: Inventory threshold reached!"

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
            statusText.text = "SMS sent successfully."
        } catch (e: Exception) {
            statusText.text = "Failed to send SMS: ${e.message}"
        }
    }

    private fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.SEND_SMS),
            SMS_PERMISSION_CODE
        )
    }

    private fun checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            sendSmsButton.visibility = Button.VISIBLE
            statusText.text = "SMS permission granted."
        } else {
            sendSmsButton.visibility = Button.GONE
            statusText.text = "Permission required for SMS notifications."
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkSmsPermission()
            } else {
                statusText.text = "Permission denied. SMS notifications disabled."
                requestSMSButton.isEnabled = false
            }
        }
    }

    companion object {
        private const val SMS_PERMISSION_CODE = 1
    }
}



