package com.example.inventoryapp

import java.time.LocalDate

class BSTNode(val item: InventoryItem) {
    var left: BSTNode? = null
    var right: BSTNode? = null
}

class InventoryBST {
    var root: BSTNode? = null

    fun insert(item: InventoryItem) {
        root = insertItem(root, item)
    }

    private fun insertItem(node: BSTNode?, item: InventoryItem): BSTNode {
        if (node == null) return BSTNode(item)
        if (item.expirationDate < node.item.expirationDate) {
            node.left = insertItem(node.left, item)
        } else {
            node.right = insertItem(node.right, item)
        }
        return node
    }

    fun search(date: LocalDate): InventoryItem? {
        return searchItem(root, date)?.item
    }

    private fun searchItem(node: BSTNode?, date: LocalDate): BSTNode? {
        if (node == null || node.item.expirationDate == date) return node
        return if (date < node.item.expirationDate) {
            searchItem(node.left, date)
        } else {
            searchItem(node.right, date)
        }
    }
}

