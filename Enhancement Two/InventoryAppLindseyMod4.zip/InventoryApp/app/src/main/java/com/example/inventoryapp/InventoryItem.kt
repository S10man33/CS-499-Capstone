package com.example.inventoryapp

import java.time.LocalDate

/**
 * Represents a single inventory item with a name, date, quantity, and optional Firestore ID.
 */
data class InventoryItem(
    val name: String,
    val date: String,
    val quantity: Int,
    val expirationDate: LocalDate,
    val priority: Int = 1,
    val id: String? = null
)








