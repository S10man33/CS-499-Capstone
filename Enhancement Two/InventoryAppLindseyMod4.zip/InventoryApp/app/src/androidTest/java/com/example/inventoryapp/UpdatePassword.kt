package com.example.inventoryapp

import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.Assert.*

@RunWith(AndroidJUnit4::class)
class FirebaseRepositoryAndroidTest {

    private val repo = FirebaseRepository()

    @Test
    fun updateUserPassword_runsWithoutCrash() = runBlocking {
        val result = repo.updateUserPassword("oldPass", "NewStrongPass1")
        assertNotNull(result)
    }
}


