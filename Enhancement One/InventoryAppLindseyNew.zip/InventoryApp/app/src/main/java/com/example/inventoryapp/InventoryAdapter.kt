package com.example.inventoryapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val items: MutableList<InventoryItem>
) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

    interface OnItemEditListener {
        fun onEdit(position: Int)
    }

    interface OnItemDeleteListener {
        fun onDelete(position: Int)
    }

    private var editListener: OnItemEditListener? = null
    private var deleteListener: OnItemDeleteListener? = null

    fun setOnItemEditListener(listener: OnItemEditListener?) {
        editListener = listener
    }

    fun setOnItemDeleteListener(listener: OnItemDeleteListener?) {
        deleteListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        val eventDate: TextView = itemView.findViewById(R.id.eventDate)
        val itemQuantity: TextView = itemView.findViewById(R.id.itemQuantity)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_inventory, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.itemName.text = item.name
        holder.eventDate.text = item.date
        holder.itemQuantity.text = item.quantity.toString()

        holder.itemName.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                editListener?.onEdit(pos)
            }
        }

        holder.deleteButton.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                deleteListener?.onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}














