package com.example.inventoryapp

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.utils.InputValidator
import kotlinx.coroutines.launch
import java.util.Calendar

class InventoryActivity : AppCompatActivity() {

    private val firebaseRepo = FirebaseRepository()
    private val inventoryList = mutableListOf<InventoryItem>()
    private lateinit var adapter: InventoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        val inventoryGrid = findViewById<RecyclerView>(R.id.inventoryGrid)
        val addItemButton = findViewById<Button>(R.id.addItemButton)
        val homeButton = findViewById<Button>(R.id.homeButton)

        adapter = InventoryAdapter(inventoryList)
        inventoryGrid.layoutManager = LinearLayoutManager(this)
        inventoryGrid.adapter = adapter

        loadInventory()

        addItemButton.setOnClickListener { showAddItemDialog() }

        adapter.setOnItemEditListener(object : InventoryAdapter.OnItemEditListener {
            override fun onEdit(position: Int) {
                showEditItemDialog(position)
            }
        })

        adapter.setOnItemDeleteListener(object : InventoryAdapter.OnItemDeleteListener {
            override fun onDelete(position: Int) {
                val item = inventoryList[position]
                if (item.id.isNullOrBlank()) {
                    Toast.makeText(this@InventoryActivity, "Missing item ID", Toast.LENGTH_SHORT).show()
                    return
                }

                AlertDialog.Builder(this@InventoryActivity)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure you want to delete '${item.name}'?")
                    .setPositiveButton("Delete") { _, _ ->
                        lifecycleScope.launch {
                            val result = firebaseRepo.deleteItem(item.id!!)
                            if (result is OperationResult.Success) {
                                inventoryList.removeAt(position)
                                adapter.notifyItemRemoved(position)
                                Toast.makeText(this@InventoryActivity, "Item deleted", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        })

        homeButton.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            })
            finish()
        }
    }

    private fun loadInventory() {
        lifecycleScope.launch {
            val items = firebaseRepo.getAllItems()
            inventoryList.clear()
            inventoryList.addAll(items)
            adapter.notifyDataSetChanged()
        }
    }

    private fun showAddItemDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.itemNameInput)
        val quantityInput = dialogView.findViewById<EditText>(R.id.itemQuantityInput)
        val dateInput = dialogView.findViewById<EditText>(R.id.itemDateInput)

        val calendar = Calendar.getInstance()
        @SuppressLint("DefaultLocale")
        val today = String.format("%04d-%02d-%02d", calendar[Calendar.YEAR], calendar[Calendar.MONTH] + 1, calendar[Calendar.DAY_OF_MONTH])
        dateInput.setText(today)

        dateInput.setOnClickListener { showDatePickerDialog(dateInput) }

        AlertDialog.Builder(this)
            .setTitle("Add New Item")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim()
                val quantityStr = quantityInput.text.toString().trim()
                val date = dateInput.text.toString().trim()

                if (!InputValidator.isNotEmpty(name, date, quantityStr)) {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (!InputValidator.isValidQuantity(quantityStr)) {
                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val item = InventoryItem(name, date, quantityStr.toInt())
                lifecycleScope.launch {
                    val result = firebaseRepo.insertItem(item)
                    if (result is OperationResult.Success) {
                        inventoryList.add(item)
                        adapter.notifyItemInserted(inventoryList.size - 1)
                    } else {
                        Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditItemDialog(position: Int) {
        val item = inventoryList[position]
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.itemNameInput)
        val quantityInput = dialogView.findViewById<EditText>(R.id.itemQuantityInput)
        val dateInput = dialogView.findViewById<EditText>(R.id.itemDateInput)

        nameInput.setText(item.name)
        quantityInput.setText(item.quantity.toString())
        dateInput.setText(item.date)

        dateInput.setOnClickListener { showDatePickerDialog(dateInput) }

        AlertDialog.Builder(this)
            .setTitle("Edit Item")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newName = nameInput.text.toString().trim()
                val quantityStr = quantityInput.text.toString().trim()
                val newDate = dateInput.text.toString().trim()

                if (!InputValidator.isNotEmpty(newName, newDate, quantityStr)) {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (!InputValidator.isValidQuantity(quantityStr)) {
                    Toast.makeText(this, "Invalid quantity", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val updatedItem = InventoryItem(newName, newDate, quantityStr.toInt(), item.id)
                lifecycleScope.launch {
                    val result = firebaseRepo.updateItem(item.id ?: "", updatedItem)
                    if (result is OperationResult.Success) {
                        inventoryList[position] = updatedItem
                        adapter.notifyItemChanged(position)
                    } else {
                        Toast.makeText(this@InventoryActivity, (result as OperationResult.Failure).message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun showDatePickerDialog(targetField: EditText) {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                @SuppressLint("DefaultLocale")
                val formattedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                targetField.setText(formattedDate)
            },
            calendar[Calendar.YEAR],
            calendar[Calendar.MONTH],
            calendar[Calendar.DAY_OF_MONTH]
        )
        datePicker.show()
    }
}




















