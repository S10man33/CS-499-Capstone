package com.example.inventoryapp

/**
 * Represents a single inventory item with a name, date, quantity, and optional Firestore ID.
 */
data class InventoryItem(
    var name: String = "",
    val date: String = "",
    val quantity: Int = 0,
    val id: String? = null // Firestore document ID
)







