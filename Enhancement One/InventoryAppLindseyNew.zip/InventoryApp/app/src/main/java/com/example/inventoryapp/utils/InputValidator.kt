package com.example.inventoryapp.utils

import android.util.Patterns

object InputValidator {

    // Checks that all provided fields are non-empty
    fun isNotEmpty(vararg fields: String): Boolean {
        return fields.all { it.isNotBlank() }
    }

    // Validates email format using Android's built-in pattern
    fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    // Validates password strength: at least 8 characters, includes number and uppercase letter
    fun isStrongPassword(password: String): Boolean {
        return password.length >= 8 &&
                password.any { it.isDigit() } &&
                password.any { it.isUpperCase() }
    }

    // Checks if two passwords match
    fun doPasswordsMatch(pw1: String, pw2: String): Boolean {
        return pw1 == pw2
    }

    // Validates quantity: must be a non-negative integer
    fun isValidQuantity(quantity: String): Boolean {
        return quantity.toIntOrNull()?.let { it >= 0 } == true
    }

    // Validates price: must be a non-negative decimal number
    fun isValidPrice(price: String): Boolean {
        return price.toDoubleOrNull()?.let { it >= 0.0 } == true
    }
}
